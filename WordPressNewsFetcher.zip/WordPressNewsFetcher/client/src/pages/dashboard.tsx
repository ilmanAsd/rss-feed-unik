import { StatusOverview } from "@/components/status-overview";
import { FeedConfiguration } from "@/components/feed-configuration";
import { RecentArticles } from "@/components/recent-articles";
import { SystemLogs } from "@/components/system-logs";
import { TechnicalInfo } from "@/components/technical-info";
import { Rss, Github, Book } from "lucide-react";
import { useRssStatus } from "@/hooks/use-rss-data";

export default function Dashboard() {
  const { data: status } = useRssStatus();

  const getStatusBadge = () => {
    if (!status) return { text: 'Loading...', color: 'bg-slate-100 text-slate-700' };
    
    switch (status.status) {
      case 'active':
        return { text: 'Service Active', color: 'bg-emerald-50 text-emerald-700' };
      case 'error':
        return { text: 'Service Error', color: 'bg-red-50 text-red-700' };
      default:
        return { text: 'Service Inactive', color: 'bg-amber-50 text-amber-700' };
    }
  };

  const statusBadge = getStatusBadge();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Rss className="text-white h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">RSS Feed Generator</h1>
                <p className="text-sm text-slate-500">UNIK Kediri News Scraper</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`flex items-center space-x-2 ${statusBadge.color} px-3 py-1 rounded-full text-sm font-medium`}>
                <div className={`w-2 h-2 rounded-full ${status?.status === 'active' ? 'bg-emerald-500 animate-pulse' : status?.status === 'error' ? 'bg-red-500' : 'bg-amber-500'}`}></div>
                <span>{statusBadge.text}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Status Overview */}
        <StatusOverview />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Feed Configuration */}
            <FeedConfiguration />

            {/* Recent Articles */}
            <RecentArticles />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* System Logs */}
            <SystemLogs />

            {/* Technical Info */}
            <TechnicalInfo />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-slate-500">
              RSS Feed Generator for UNIK Kediri • Built with Node.js & Express
            </div>
            <div className="flex items-center space-x-4">
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors duration-200">
                <Github className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors duration-200">
                <Book className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
