import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useServerInfo } from "@/hooks/use-rss-data";
import { Skeleton } from "@/components/ui/skeleton";

export function TechnicalInfo() {
  const { data: serverInfo, isLoading } = useServerInfo();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Technical Information</CardTitle>
          <p className="text-sm text-slate-500">Implementation details</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-slate-700 mb-2">Server Status</h3>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const dependencies = [
    { name: 'Express.js', version: '^4.21.2' },
    { name: 'Cheerio', version: '^1.0.0' },
    { name: 'Node-cron', version: '^3.0.2' },
    { name: 'React', version: '^18.3.1' },
  ];

  const apiEndpoints = [
    { method: 'GET', path: '/rss.xml', description: 'RSS Feed' },
    { method: 'GET', path: '/api/status', description: 'System Status' },
    { method: 'POST', path: '/api/refresh', description: 'Manual Refresh' },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Technical Information</CardTitle>
        <p className="text-sm text-slate-500">Implementation details</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {serverInfo && (
          <div>
            <h3 className="text-sm font-medium text-slate-700 mb-2">Server Status</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Node.js Version</span>
                <span className="text-slate-900 font-mono">{serverInfo.nodeVersion}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Memory Usage</span>
                <span className="text-slate-900 font-mono">{serverInfo.memoryUsage}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Uptime</span>
                <span className="text-slate-900 font-mono">{serverInfo.uptime}</span>
              </div>
            </div>
          </div>
        )}

        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-2">Dependencies</h3>
          <div className="space-y-1 text-sm">
            {dependencies.map((dep, index) => (
              <div key={index} className="flex justify-between">
                <span className="text-slate-500">{dep.name}</span>
                <span className="text-slate-900 font-mono">{dep.version}</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-2">API Endpoints</h3>
          <div className="space-y-2">
            {apiEndpoints.map((endpoint, index) => (
              <div key={index} className="bg-slate-50 p-3 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Badge 
                    className={`text-xs font-medium ${
                      endpoint.method === 'GET' 
                        ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-100' 
                        : 'bg-amber-100 text-amber-800 hover:bg-amber-100'
                    }`}
                  >
                    {endpoint.method}
                  </Badge>
                  <code className="text-sm text-slate-900">{endpoint.path}</code>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
