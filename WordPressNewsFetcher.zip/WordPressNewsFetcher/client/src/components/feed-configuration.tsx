import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, ExternalLink, RefreshCw } from "lucide-react";
import { useSettings, useUpdateSetting, useRefreshFeed } from "@/hooks/use-rss-data";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function FeedConfiguration() {
  const { data: settings } = useSettings();
  const updateSetting = useUpdateSetting();
  const refreshFeed = useRefreshFeed();
  const { toast } = useToast();

  const [updateInterval, setUpdateInterval] = useState<string>('15');
  const [maxArticles, setMaxArticles] = useState<string>('20');

  // Get current settings values
  const currentInterval = settings?.find(s => s.key === 'updateInterval')?.value || '15';
  const currentMaxArticles = settings?.find(s => s.key === 'maxArticles')?.value || '20';

  // Generate RSS URL
  const getRssUrl = () => {
    if (typeof window !== 'undefined') {
      return `${window.location.origin}/rss.xml`;
    }
    return 'https://your-replit-app.replit.dev/rss.xml';
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(getRssUrl());
      toast({
        title: "Success",
        description: "RSS URL copied to clipboard!",
      });
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to copy URL to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleUpdateSettings = async () => {
    try {
      await updateSetting.mutateAsync({ key: 'updateInterval', value: updateInterval });
      await updateSetting.mutateAsync({ key: 'maxArticles', value: maxArticles });
      
      toast({
        title: "Success",
        description: "Settings updated successfully!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    }
  };

  const handleRefreshFeed = async () => {
    try {
      await refreshFeed.mutateAsync();
      toast({
        title: "Success", 
        description: "Feed refresh initiated successfully!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh feed",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>RSS Feed Endpoint</CardTitle>
        <p className="text-sm text-slate-500">Use this URL in your WordPress RSS reader</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-sm font-medium text-slate-700">RSS Feed URL</Label>
          <div className="flex items-center space-x-2 mt-2">
            <Input 
              value={getRssUrl()}
              readOnly
              className="font-mono text-sm bg-slate-50"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={copyToClipboard}
              className="bg-blue-600 hover:bg-blue-700 text-white border-blue-600"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-slate-700">Source Website</Label>
          <div className="flex items-center space-x-2 mt-2">
            <Input 
              value="https://unik-kediri.ac.id/list-berita"
              readOnly
              className="bg-slate-50"
            />
            <Button
              variant="outline"
              size="icon"
              asChild
              className="bg-slate-600 hover:bg-slate-700 text-white border-slate-600"
            >
              <a href="https://unik-kediri.ac.id/list-berita" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-slate-700">Update Interval</Label>
            <Select 
              value={updateInterval || currentInterval} 
              onValueChange={setUpdateInterval}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select interval" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Every 5 minutes</SelectItem>
                <SelectItem value="15">Every 15 minutes</SelectItem>
                <SelectItem value="30">Every 30 minutes</SelectItem>
                <SelectItem value="60">Every hour</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-sm font-medium text-slate-700">Max Articles</Label>
            <Select 
              value={maxArticles || currentMaxArticles} 
              onValueChange={setMaxArticles}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select max articles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 articles</SelectItem>
                <SelectItem value="20">20 articles</SelectItem>
                <SelectItem value="50">50 articles</SelectItem>
                <SelectItem value="100">100 articles</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-200">
          <Button 
            onClick={handleUpdateSettings}
            disabled={updateSetting.isPending}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {updateSetting.isPending ? "Updating..." : "Update Settings"}
          </Button>
          <Button 
            onClick={handleRefreshFeed}
            disabled={refreshFeed.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${refreshFeed.isPending ? 'animate-spin' : ''}`} />
            {refreshFeed.isPending ? "Refreshing..." : "Refresh Now"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
