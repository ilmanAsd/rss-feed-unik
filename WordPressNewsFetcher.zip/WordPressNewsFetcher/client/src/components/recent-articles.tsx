import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Newspaper, ExternalLink } from "lucide-react";
import { useArticles } from "@/hooks/use-rss-data";
import { Skeleton } from "@/components/ui/skeleton";
import type { Article } from "@shared/schema";

export function RecentArticles() {
  const { data: articles, isLoading } = useArticles(10);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Articles</CardTitle>
          <p className="text-sm text-slate-500">Latest scraped news from UNIK Kediri</p>
        </CardHeader>
        <CardContent className="divide-y divide-slate-200">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="p-6">
              <div className="flex items-start space-x-4">
                <Skeleton className="w-12 h-12 rounded-lg" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!articles || articles.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Articles</CardTitle>
          <p className="text-sm text-slate-500">Latest scraped news from UNIK Kediri</p>
        </CardHeader>
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center space-y-2">
            <Newspaper className="h-12 w-12 text-slate-400" />
            <p className="text-slate-500">No articles found</p>
            <p className="text-xs text-slate-400">Try refreshing the feed to scrape new content</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (error) {
      return dateString;
    }
  };

  const truncateText = (text: string, maxLength: number = 150) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Articles</CardTitle>
        <p className="text-sm text-slate-500">Latest scraped news from UNIK Kediri</p>
      </CardHeader>
      <CardContent className="divide-y divide-slate-200">
        {articles.map((article: Article) => (
          <div key={article.id} className="p-6 hover:bg-slate-50 transition-colors duration-200">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Newspaper className="text-blue-600 h-6 w-6" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-sm font-medium text-slate-900 line-clamp-2 mb-1">
                      {article.title}
                    </h3>
                    {article.excerpt && (
                      <p className="text-sm text-slate-500 line-clamp-2 mb-2">
                        {truncateText(article.excerpt)}
                      </p>
                    )}
                    <div className="flex items-center text-xs text-slate-400 space-x-2">
                      <span>{formatDate(article.publishedDate || article.scrapedAt.toString())}</span>
                      {article.category && (
                        <>
                          <span>•</span>
                          <span>{article.category}</span>
                        </>
                      )}
                      {article.url && (
                        <>
                          <span>•</span>
                          <a 
                            href={article.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                          >
                            <ExternalLink className="h-3 w-3" />
                            <span>Source</span>
                          </a>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex-shrink-0 ml-4">
                    <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                      Published
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
