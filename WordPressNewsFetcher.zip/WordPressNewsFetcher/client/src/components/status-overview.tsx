import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Clock, Newspaper, TrendingUp, AlertCircle, XCircle } from "lucide-react";
import { useRssStatus } from "@/hooks/use-rss-data";
import { Skeleton } from "@/components/ui/skeleton";

export function StatusOverview() {
  const { data: status, isLoading } = useRssStatus();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!status) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Feed Status</p>
                <p className="text-2xl font-semibold text-slate-900">Error</p>
              </div>
              <div className="bg-red-100 p-3 rounded-lg">
                <XCircle className="text-red-600 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusIcon = () => {
    switch (status.status) {
      case 'active':
        return <CheckCircle className="text-emerald-600 h-6 w-6" />;
      case 'error':
        return <XCircle className="text-red-600 h-6 w-6" />;
      default:
        return <AlertCircle className="text-amber-600 h-6 w-6" />;
    }
  };

  const getStatusColor = () => {
    switch (status.status) {
      case 'active':
        return 'bg-emerald-100';
      case 'error':
        return 'bg-red-100';
      default:
        return 'bg-amber-100';
    }
  };

  const getStatusText = () => {
    switch (status.status) {
      case 'active':
        return 'Active';
      case 'error':
        return 'Error';
      default:
        return 'Inactive';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Feed Status</p>
              <p className="text-2xl font-semibold text-slate-900">{getStatusText()}</p>
            </div>
            <div className={`${getStatusColor()} p-3 rounded-lg`}>
              {getStatusIcon()}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Last Update</p>
              <p className="text-2xl font-semibold text-slate-900">{status.lastUpdate}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Clock className="text-blue-600 h-6 w-6" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Articles Found</p>
              <p className="text-2xl font-semibold text-slate-900">{status.articleCount}</p>
            </div>
            <div className="bg-amber-100 p-3 rounded-lg">
              <Newspaper className="text-amber-600 h-6 w-6" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Success Rate</p>
              <p className="text-2xl font-semibold text-slate-900">{status.successRate}%</p>
            </div>
            <div className="bg-emerald-100 p-3 rounded-lg">
              <TrendingUp className="text-emerald-600 h-6 w-6" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
