import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useSystemLogs } from "@/hooks/use-rss-data";
import { Skeleton } from "@/components/ui/skeleton";
import type { SystemLog } from "@shared/schema";

export function SystemLogs() {
  const { data: logs, isLoading } = useSystemLogs(50);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>System Logs</CardTitle>
          <p className="text-sm text-slate-500">Real-time scraping activity</p>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            <div className="space-y-3">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="flex items-start space-x-3">
                  <Skeleton className="w-2 h-2 rounded-full mt-1" />
                  <div className="flex-1 space-y-1">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    );
  }

  if (!logs || logs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>System Logs</CardTitle>
          <p className="text-sm text-slate-500">Real-time scraping activity</p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-96">
            <p className="text-slate-500">No logs available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getLogColor = (level: string) => {
    switch (level) {
      case 'success':
        return 'bg-emerald-500';
      case 'error':
        return 'bg-red-500';
      case 'warn':
        return 'bg-amber-500';
      case 'info':
      default:
        return 'bg-blue-500';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    try {
      const date = new Date(timestamp);
      return date.toLocaleString('id-ID', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch (error) {
      return timestamp;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Logs</CardTitle>
        <p className="text-sm text-slate-500">Real-time scraping activity</p>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-3">
            {logs.map((log: SystemLog) => (
              <div key={log.id} className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-1">
                  <div className={`w-2 h-2 ${getLogColor(log.level)} rounded-full`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-900 break-words">
                    {log.message}
                  </p>
                  <p className="text-xs text-slate-500">
                    {formatTimestamp(log.timestamp.toString())}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
