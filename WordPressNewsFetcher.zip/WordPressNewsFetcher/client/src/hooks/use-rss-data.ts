import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { RssStatus, Article, SystemLog, Setting, ServerInfo } from '@shared/schema';

export function useRssStatus() {
  return useQuery<RssStatus>({
    queryKey: ['/api/status'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
}

export function useArticles(limit: number = 20) {
  return useQuery<Article[]>({
    queryKey: ['/api/articles', limit],
    refetchInterval: 60000, // Refresh every minute
  });
}

export function useSystemLogs(limit: number = 50) {
  return useQuery<SystemLog[]>({
    queryKey: ['/api/logs', limit],
    refetchInterval: 15000, // Refresh every 15 seconds
  });
}

export function useServerInfo() {
  return useQuery<ServerInfo>({
    queryKey: ['/api/server-info'],
    refetchInterval: 60000, // Refresh every minute
  });
}

export function useSettings() {
  return useQuery<Setting[]>({
    queryKey: ['/api/settings'],
  });
}

export function useUpdateSetting() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ key, value }: { key: string; value: string }) => {
      const response = await apiRequest('POST', '/api/settings', { key, value });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/status'] });
    },
  });
}

export function useRefreshFeed() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/refresh');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
    },
  });
}
